import pytest
from unittest.mock import patch


@pytest.fixture(autouse=True)
def mock_generate_embeddings():
    """Patch generate_embeddings so we avoid calling real models."""
    fake_embedding = [0.1] * 384  # match sentence-transformer dimension
    with patch("server.src.ingestion.embeddings.generate_embeddings", return_value=[fake_embedding]):
        yield
